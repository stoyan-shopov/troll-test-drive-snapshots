build with:
arm-none-eabi-gcc -g -flto import.c -o import.elf --specs=nosys.specs
