#!/bin/bash

CFLAGS="-O3 -gdwarf-4 -ggdb3 -finline-functions -fvar-tracking -fvar-tracking-assignments -fdebug-types-section" make
