/*
 * This file is part of the Black Magic Debug project.
 *
 * Copyright (C) 2011  Black Sphere Technologies Ltd.
 * Written by Gareth McMullin <gareth@blacksphere.co.nz>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/* Provides main entry point.  Initialise subsystems and enter GDB
 * protocol loop.
 */

/* Build with:
   CFLAGS="-Og -gdwarf-5" make main.o &&  arm-none-eabi-objdump -W main.o |grep entry
   */

#include "general.h"
#include "gdb_if.h"
#include "gdb_main.h"
#include "target.h"
#include "exception.h"
#include "gdb_packet.h"
#include "morse.h"

int gate4(int(*f1)(int,int,int), int(*f2)(int(*)(int,int,int),int,int,int), int a, int b, int c);
int gate3(int(*f)(int,int,int), int a, int b, int c);
int f1(int a, int b, int c);

volatile xxx = 1;

int
main(int argc, char **argv)
{
#if defined(LIBFTDI)
	platform_init(argc, argv);
#else
	(void) argc;
	(void) argv;
	platform_init();
#endif
	while (xxx)
		xxx += gate4(f1, gate3, 0x69, 0x3a, 0x57);

	while (true) {
		volatile struct exception e;
		TRY_CATCH(e, EXCEPTION_ALL) {
			gdb_main();
		}
		if (e.type) {
			gdb_putpacketz("EFF");
			target_list_free();
			morse("TARGET LOST.", 1);
		}
	}

	/* Should never get here */
	return 0;
}



#if 0
/*
$ CFLAGS="-Og -gdwarf-5" make main.o &&  arm-none-eabi-objdump -W main.o |grep entry
  GIT     include/version.h
fatal: Not a git repository (or any of the parent directories): .git
  CC      main.c
    <a77>   DW_AT_name        : (indirect string, offset: 0xc6e3): entry_test
    <ae3>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 51    (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)))
    <aea>   DW_AT_GNU_call_site_value: 7 byte block: f3 1 52 f3 1 50 1c         (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_minus)
    <af5>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 50    (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)))
    <b66>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 50    (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)))
    <c20>   DW_AT_entry_pc    : 0x10
    <c24>   DW_AT_GNU_entry_view: 2
    <c5d>   DW_AT_entry_pc    : 0x30
    <c61>   DW_AT_GNU_entry_view: 1
    DW_AT_entry_pc     DW_FORM_addr
    DW_AT_GNU_entry_view DW_FORM_data1
    DW_AT_entry_pc     DW_FORM_addr
    DW_AT_GNU_entry_view DW_FORM_data1
             000000b9 000000be (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             000000b9 000000be (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             000000b6 000000be (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             0000005f 00000062 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000028 00000030 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000026 00000028 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_breg0 (r0): 0; DW_OP_plus; DW_OP_stack_value)
             00000028 00000030 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_plus; DW_OP_stack_value)
             00000024 0000002a (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000008 00000010 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000006 00000010 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
  0x0000c6e0 47290065 6e747279 5f746573 74004750 G).entry_test.GP

   */
volatile int entry_test;

int f0(int a, int b, int c)
{
	return a + b * entry_test - c;
}

int f3(int a, int b, int c)
{
	entry_test += f0(c, b, a);
	b = a + c;
	c = b + a - entry_test;
	a = b = c + entry_test;
	entry_test += a + b + c - f0(a, 1, c);
	return a * b + c * entry_test;
}

/*
int f2(int a, int b, int c)
{
	a = f3(b, c, a);
	b += f3(c * 3, a ^ 7, b - 3);
	c -= a * entry_test;
	entry_test += a * b - c;
	return a + b + c + entry_test;
}
*/
int f2(int a, int b, int c)
{
	a = f3(b, c, a);
	f3(b, c, a);
	b = f3(b, c, a);
	b += f3(c * 3, a ^ 7, b - 3);
	c -= a * entry_test;
	entry_test += a * b - c;
	return a + b + c + entry_test;
}

int f1(int a, int b, int c)
{
	return f2(b, c - a, a) + 3;
}

#endif


#if 0
/*
$ CFLAGS="-Og -gdwarf-5" make main.o &&  arm-none-eabi-objdump -W main.o |grep entry
  GIT     include/version.h
fatal: Not a git repository (or any of the parent directories): .git
  CC      main.c
    <a77>   DW_AT_name        : (indirect string, offset: 0xc6e3): entry_test
    <ae3>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 51    (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)))
    <aea>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 52    (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)))
    <af1>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 50    (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)))
    <b5e>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 50    (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)))
    <bb8>   DW_AT_entry_pc    : 0x10
    <bbc>   DW_AT_GNU_entry_view: 2
    <bf5>   DW_AT_entry_pc    : 0x30
    <bf9>   DW_AT_GNU_entry_view: 1
    DW_AT_entry_pc     DW_FORM_addr
    DW_AT_GNU_entry_view DW_FORM_data1
    DW_AT_entry_pc     DW_FORM_addr
    DW_AT_GNU_entry_view DW_FORM_data1
             0000007d 00000080 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             0000007d 00000080 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             0000007d 00000080 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             0000005d 0000005e (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000068 00000070 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000068 00000070 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000028 00000030 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000026 00000028 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_breg0 (r0): 0; DW_OP_plus; DW_OP_stack_value)
             00000028 00000030 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_plus; DW_OP_stack_value)
             00000024 0000002a (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000008 00000010 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000006 00000010 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
  0x0000c6e0 47290065 6e747279 5f746573 74004750 G).entry_test.GP


   */
volatile int entry_test;

int f0(int a, int b, int c)
{
	return a + b * entry_test - c;
}

int f3(int a, int b, int c)
{
	entry_test += f0(c, b, a);
	b = a + c;
	c = b + a - entry_test;
	a = b = c + entry_test;
	entry_test += a + b + c - f0(a, 1, c);
	return a * b + c * entry_test;
}

int f2(int a, int b, int c)
{
	a = f3(c, b, a);
	return a + b + c + entry_test;
}

int f1(int a, int b, int c)
{
	return f2(b, c, a);
}

#endif

#if 0
/*
$ CFLAGS="-Og -gdwarf-5" make main.o &&  arm-none-eabi-objdump -W main.o |grep entry
  GIT     include/version.h
fatal: Not a git repository (or any of the parent directories): .git
  CC      main.c
    <a77>   DW_AT_name        : (indirect string, offset: 0xc6e3): entry_test
    <ae3>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 51    (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)))
    <aea>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 52    (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)))
    <af1>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 50    (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)))
    <bb7>   DW_AT_entry_pc    : 0x10
    <bbb>   DW_AT_GNU_entry_view: 2
    <bf4>   DW_AT_entry_pc    : 0x30
    <bf8>   DW_AT_GNU_entry_view: 1
    DW_AT_entry_pc     DW_FORM_addr
    DW_AT_GNU_entry_view DW_FORM_data1
    DW_AT_entry_pc     DW_FORM_addr
    DW_AT_GNU_entry_view DW_FORM_data1
             00000081 00000084 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000081 00000084 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000081 00000084 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             0000006e 00000074 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             0000006e 00000074 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_shl; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor; DW_OP_stack_value)
             0000006e 00000074 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_shl; DW_OP_stack_value)
             00000028 00000030 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000026 00000028 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_breg0 (r0): 0; DW_OP_plus; DW_OP_stack_value)
             00000028 00000030 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_plus; DW_OP_stack_value)
             00000024 0000002a (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000008 00000010 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000006 00000010 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
  0x0000c6e0 47290065 6e747279 5f746573 74004750 G).entry_test.GP

   */
volatile int entry_test;

int f0(int a, int b, int c)
{
	return a + b * entry_test - c;
}

int f3(int a, int b, int c)
{
	entry_test += f0(c, b, a);
	b = a + c;
	c = b + a - entry_test;
	a = b = c + entry_test;
	entry_test += a + b + c - f0(a, 1, c);
	return a * b + c * entry_test;
}

int f2(int a, int b, int c)
{
	//a = f3(c, b, a);
	c = a << b;
	b = a ^ c;
	f3(a, b, c);
	return a + b + c + entry_test;
}

int f1(int a, int b, int c)
{
	return f2(b, c, a);
}

#endif

#if 0
/*
$ CFLAGS="-Og -gdwarf-5" make main.o &&  arm-none-eabi-objdump -W main.o |grep entry
  GIT     include/version.h
fatal: Not a git repository (or any of the parent directories): .git
  CC      main.c
main.c: In function 'f2':
main.c:200:8: warning: suggest parentheses around arithmetic in operand of '|' [-Wparentheses]
  a = a & b | c;
      ~~^~~
    <a77>   DW_AT_name        : (indirect string, offset: 0xc6e3): entry_test
    <af9>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 51    (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)))
    <b00>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 52    (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)))
    <b07>   DW_AT_GNU_call_site_value: 6 byte block: 74 0 f3 1 50 27    (DW_OP_breg4 (r4): 0; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor)
    <bea>   DW_AT_entry_pc    : 0x10
    <bee>   DW_AT_GNU_entry_view: 2
    <c27>   DW_AT_entry_pc    : 0x16
    <c2b>   DW_AT_GNU_entry_view: 3
    <c68>   DW_AT_entry_pc    : 0x1e
    <c6c>   DW_AT_GNU_entry_view: 1
    DW_AT_entry_pc     DW_FORM_addr
    DW_AT_GNU_entry_view DW_FORM_data1
    DW_AT_entry_pc     DW_FORM_addr
    DW_AT_GNU_entry_view DW_FORM_data1
    DW_AT_entry_pc     DW_FORM_addr
    DW_AT_GNU_entry_view DW_FORM_data1
             00000075 00000084 (DW_OP_breg4 (r4): 0; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor; DW_OP_stack_value)
             00000084 00000086 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_plus; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor; DW_OP_stack_value)
             00000075 0000007a (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000084 00000086 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_plus; DW_OP_stack_value)
             00000075 00000086 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000048 0000004c (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             0000005e 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_not; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_and; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor; DW_OP_shl; DW_OP_or; DW_OP_stack_value)
             0000005e 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor; DW_OP_stack_value)
             0000005e 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor; DW_OP_shl; DW_OP_stack_value)
             00000024 0000003c (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000016 00000016 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000022 00000024 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_breg0 (r0): 0; DW_OP_plus; DW_OP_stack_value)
             00000024 0000003c (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_plus; DW_OP_stack_value)
             00000014 0000001e (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000034 0000003c (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_lit1; DW_OP_shl; DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_plus; DW_OP_stack_value)
             00000014 00000016 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000016 00000018 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000008 00000010 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000006 00000010 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
  0x0000c6e0 47290065 6e747279 5f746573 74004750 G).entry_test.GP

   */
volatile int entry_test;

int f0(int a, int b, int c)
{
	return a + b * entry_test - c;
}

int f3(int a, int b, int c)
{
	f0(c, b, a);
	b = a + c;
	f0(a, b, c);
	c = b + a;
	entry_test += a + b + c - f0(a, 1, c);
	return a * b + c * entry_test;
}

int f2(int a, int b, int c)
{
	//a = f3(c, b, a);
	b = a ^ c;
	c = a << b;
	a = a & b | c;
	f3(a, b, c);
	return a + b + c + entry_test;
}

int f1(int a, int b, int c)
{
	a ^= b + c;
	int x = f2(b, c, a);
	b += c;
	return x + f2(1, 2, b);
}


#endif

#if 0
/*
$ CFLAGS="-Og -gdwarf-5" make main.o &&  arm-none-eabi-objdump -W main.o |grep entry
  GIT     include/version.h
fatal: Not a git repository (or any of the parent directories): .git
  CC      main.c
main.c: In function 'f2':
main.c:240:8: warning: suggest parentheses around arithmetic in operand of '|' [-Wparentheses]
  a = a & b | c;
      ~~^~~
    <a77>   DW_AT_name        : (indirect string, offset: 0xc6e3): entry_test
    <af9>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 51    (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)))
    <b00>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 52    (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)))
    <b07>   DW_AT_GNU_call_site_value: 6 byte block: 74 0 f3 1 50 27    (DW_OP_breg4 (r4): 0; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor)
    <b89>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 50    (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)))
    <c0a>   DW_AT_entry_pc    : 0x10
    <c0e>   DW_AT_GNU_entry_view: 2
    <c47>   DW_AT_entry_pc    : 0x16
    <c4b>   DW_AT_GNU_entry_view: 3
    <c88>   DW_AT_entry_pc    : 0x1e
    <c8c>   DW_AT_GNU_entry_view: 1
    DW_AT_entry_pc     DW_FORM_addr
    DW_AT_GNU_entry_view DW_FORM_data1
    DW_AT_entry_pc     DW_FORM_addr
    DW_AT_GNU_entry_view DW_FORM_data1
    DW_AT_entry_pc     DW_FORM_addr
    DW_AT_GNU_entry_view DW_FORM_data1
             00000081 00000090 (DW_OP_breg4 (r4): 0; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor; DW_OP_stack_value)
             00000090 00000092 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_plus; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor; DW_OP_stack_value)
             00000081 00000086 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000090 00000092 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_plus; DW_OP_stack_value)
             00000081 00000092 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000055 00000056 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             0000006a 0000006a (DW_OP_breg7 (r7): 0; DW_OP_not; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_and; DW_OP_breg6 (r6): 0; DW_OP_or; DW_OP_stack_value) (start == end)
             0000006a 0000006a (DW_OP_breg7 (r7): 0; DW_OP_not; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_and; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_breg7 (r7): 0; DW_OP_xor; DW_OP_shl; DW_OP_or; DW_OP_stack_value) (start == end)
             0000006a 00000070 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_not; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_and; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor; DW_OP_shl; DW_OP_or; DW_OP_stack_value)
             0000006a 0000006a (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_breg7 (r7): 0; DW_OP_xor; DW_OP_stack_value) (start == end)
             0000006a 00000070 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor; DW_OP_stack_value)
             0000006a 0000006a (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_breg7 (r7): 0; DW_OP_xor; DW_OP_shl; DW_OP_stack_value) (start == end)
             0000006a 00000070 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor; DW_OP_shl; DW_OP_stack_value)
             00000024 0000003c (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000016 00000016 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000022 00000024 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_breg0 (r0): 0; DW_OP_plus; DW_OP_stack_value)
             00000024 0000003c (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_plus; DW_OP_stack_value)
             00000014 0000001e (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000034 0000003c (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_lit1; DW_OP_shl; DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_plus; DW_OP_stack_value)
             00000014 00000016 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000016 00000018 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000008 00000010 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000006 00000010 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
  0x0000c6e0 47290065 6e747279 5f746573 74004750 G).entry_test.GP

   */
volatile int entry_test;

int f0(int a, int b, int c)
{
	return a + b * entry_test - c;
}

int f3(int a, int b, int c)
{
	f0(c, b, a);
	b = a + c;
	f0(a, b, c);
	c = b + a;
	entry_test += a + b + c - f0(a, 1, c);
	return a * b + c * entry_test;
}

int f2(int a, int b, int c)
{
	//a = f3(c, b, a);
	b = a ^ c;
	f3(a, 2, b);
	c = a << b;
	a = a & b | c;
	f3(a, b, c);
	return a + b + c + entry_test;
}

int f1(int a, int b, int c)
{
	a ^= b + c;
	int x = f2(b, c, a);
	b += c;
	return x + f2(1, 2, b);
}


#endif

#if 0
/*
$ CFLAGS="-Og -gdwarf-5" make main.o &&  arm-none-eabi-objdump -W main.o |grep entry
  GIT     include/version.h
fatal: Not a git repository (or any of the parent directories): .git
  CC      main.c
    <a77>   DW_AT_name        : (indirect string, offset: 0xc6e3): entry_test
    <ae8>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 51    (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)))
    <aef>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 52    (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)))
    <af6>   DW_AT_GNU_call_site_value: 11 byte block: f3 1 51 f3 1 52 22 f3 1 50 27     (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_plus; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor)
    <b63>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 50    (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)))
    <b6f>   DW_AT_GNU_call_site_value: 7 byte block: f3 1 50 f3 1 52 27         (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor)
    <bd1>   DW_AT_entry_pc    : 0x10
    <bd5>   DW_AT_GNU_entry_view: 2
    <c0f>   DW_AT_entry_pc    : 0x16
    <c13>   DW_AT_GNU_entry_view: 3
    DW_AT_entry_pc     DW_FORM_addr
    DW_AT_GNU_entry_view DW_FORM_data1
    DW_AT_entry_pc     DW_FORM_addr
    DW_AT_GNU_entry_view DW_FORM_data1
             00000043 00000046 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_plus; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor; DW_OP_stack_value)
             00000043 00000046 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000043 00000046 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000031 00000034 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000031 00000034 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor; DW_OP_stack_value)
             0000002c 00000034 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             0000001e 00000028 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000016 00000016 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000014 00000018 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000020 00000028 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_breg2 (r2): 0; DW_OP_plus; DW_OP_stack_value)
             00000014 00000016 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000016 00000018 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000008 00000010 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000006 00000010 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
  0x0000c6e0 47290065 6e747279 5f746573 74004750 G).entry_test.GP

   */
volatile int entry_test;

int f0(int a, int b, int c)
{
	return a + b * entry_test - c;
}

int f3(int a, int b, int c)
{
	f0(c, b, a);
	b = a + c;
	f0(a, b, c);
	c = b + a;
	return a * b + c;
}

int f2(int a, int b, int c)
{
	b = a ^ c;
	return f3(a, 2, b);
}

int f1(int a, int b, int c)
{
	a ^= b + c;
	return f2(b, c, a);
}


#endif


#if 0
/*
  GIT     include/version.h
fatal: Not a git repository (or any of the parent directories): .git
  CC      main.c
    <a77>   DW_AT_name        : (indirect string, offset: 0xc6e3): entry_test
    <ae8>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 51    (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)))
    <aef>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 52    (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)))
    <af6>   DW_AT_GNU_call_site_value: 11 byte block: f3 1 51 f3 1 52 22 f3 1 50 27     (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_plus; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor)
    <b63>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 50    (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)))
    <b6f>   DW_AT_GNU_call_site_value: 7 byte block: f3 1 50 f3 1 52 27         (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor)
    <bdc>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 52    (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)))
             00000059 0000005c (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_plus; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor; DW_OP_stack_value)
             00000059 0000005c (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000059 0000005c (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000047 0000004a (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000047 0000004a (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor; DW_OP_stack_value)
             00000042 0000004a (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             0000003c 0000003e (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             0000003c 0000003e (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             0000002d 00000034 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             0000003c 0000003c (DW_OP_breg5 (r5): 0; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_plus; DW_OP_stack_value) (start == end)
             0000003c 0000003e (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_plus; DW_OP_stack_value)
             00000016 00000020 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000014 00000020 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg1 (
   */
volatile int entry_test;

int f0(int a, int b, int c)
{
	//a ^= b;
	//b >>= c;
	entry_test += a * b + c;
	return a + b * entry_test - c;
}

int f3(int a, int b, int c)
{
	f0(c, b, a);
	c = b + a;
	return f0(a * b + c, b, c);
}

int f2(int a, int b, int c)
{
	b = a ^ c;
	return f3(a, 2, b);
}

int f1(int a, int b, int c)
{
	a ^= b + c;
	return f2(b, c, a);
}


#endif


#if 0
/*
$ CFLAGS="-Og -gdwarf-5" make main.o &&  arm-none-eabi-objdump -W main.o |grep entry
  GIT     include/version.h
fatal: Not a git repository (or any of the parent directories): .git
  CC      main.c
    <a77>   DW_AT_name        : (indirect string, offset: 0xc6e3): entry_test
    <ae8>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 51    (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)))
    <aef>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 52    (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)))
    <af6>   DW_AT_GNU_call_site_value: 11 byte block: f3 1 51 f3 1 52 22 f3 1 50 27     (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_plus; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor)
    <b63>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 50    (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)))
    <b6f>   DW_AT_GNU_call_site_value: 7 byte block: f3 1 50 f3 1 52 27         (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor)
    <bdc>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 52    (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)))
             00000059 0000005c (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_plus; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor; DW_OP_stack_value)
             00000059 0000005c (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000059 0000005c (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000047 0000004a (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000047 0000004a (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor; DW_OP_stack_value)
             00000042 0000004a (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             0000003c 0000003e (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             0000003c 0000003e (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             0000002d 00000034 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             0000003c 0000003c (DW_OP_breg5 (r5): 0; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_plus; DW_OP_stack_value) (start == end)
             0000003c 0000003e (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_plus; DW_OP_stack_value)
             00000016 00000020 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000014 00000020 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
  0x0000c6e0 47290065 6e747279 5f746573 74004750 G).entry_test.GP
*/   


volatile int entry_test;

int f0(int a, int b, int c)
{
	//a ^= b;
	//b >>= c;
	entry_test += a * b + c;
	return a + b * entry_test - c;
}

int f3(int a, int b, int c)
{
	f0(c, b, a);
	c = b + a;
	return f0(a * b + c, b, c);
}

int f2(int a, int b, int c)
{
	b = a ^ c;
	return f3(a, 2, b);
}

int f1(int a, int b, int c)
{
	a ^= b + c;
	return f2(b, c, a);
}


#endif


#if 0
/*
$ CFLAGS="-Og -gdwarf-5" make main.o &&  arm-none-eabi-objdump -W main.o |grep entry
  GIT     include/version.h
fatal: Not a git repository (or any of the parent directories): .git
  CC      main.c
    <a77>   DW_AT_name        : (indirect string, offset: 0xc6e9): entry_test
    <afb>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 53    (DW_OP_GNU_entry_value: (DW_OP_reg3 (r3)))
    <b02>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 51    (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)))
    <b09>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 52    (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)))
    <b8d>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 51    (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)))
    <b94>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 52    (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)))
    <b9b>   DW_AT_GNU_call_site_value: 11 byte block: f3 1 51 f3 1 52 22 f3 1 50 27     (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_plus; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor)
    <c08>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 50    (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)))
    <c14>   DW_AT_GNU_call_site_value: 7 byte block: f3 1 50 f3 1 52 27         (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor)
    <c81>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 52    (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)))
             00000064 00000066 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000063 00000066 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000063 00000066 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000063 00000066 (DW_OP_GNU_entry_value: (DW_OP_reg3 (r3)); DW_OP_stack_value)
             00000059 0000005c (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_plus; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor; DW_OP_stack_value)
             00000059 0000005c (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000059 0000005c (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000047 0000004a (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000047 0000004a (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor; DW_OP_stack_value)
             00000042 0000004a (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             0000003c 0000003e (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             0000003c 0000003e (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             0000002d 00000034 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             0000003c 0000003c (DW_OP_breg5 (r5): 0; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_plus; DW_OP_stack_value) (start == end)
             0000003c 0000003e (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_plus; DW_OP_stack_value)
             00000016 00000020 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000014 00000020 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000007 00000064 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
  0x0000c6e0 52284750 494f4729 00656e74 72795f74 R(GPIOG).entry_t
*/   


volatile int entry_test;

int f0(int a, int b, int c)
{
	//a ^= b;
	//b >>= c;
	entry_test += a * b + c;
	return a + b * entry_test - c;
}

int f3(int a, int b, int c)
{
	f0(c, b, a);
	c = b + a;
	return f0(a * b + c, b, c);
}

int f2(int a, int b, int c)
{
	b = a ^ c;
	return f3(a, 2, b);
}

int f1(int a, int b, int c)
{
	a ^= b + c;
	return f2(b, c, a);
}

int gate1(int(*f)(int,int,int), int a, int b, int c)
{
	return f(c, a, b);
}


#endif


#if 1
/*
sshopov@sshopov-w01 MSYS /c/src/build-troll-Desktop_Qt_5_12_0_MinGW_64_bit-Debug/troll-test-drive-files/blackmagic/src
$ CFLAGS="-Og -gdwarf-5" make main.o &&  arm-none-eabi-objdump -W main.o |grep entry
  GIT     include/version.h
fatal: Not a git repository (or any of the parent directories): .git
  CC      main.c
main.c:41:10: warning: type defaults to 'int' in declaration of 'xxx' [-Wimplicit-int]
 volatile xxx = 1;
          ^~~
    <a89>   DW_AT_name        : (indirect string, offset: 0xc6fb): entry_test
    <b96>   DW_AT_entry_pc    : 0x7a
    <b9a>   DW_AT_GNU_entry_view: 0
    <be3>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 50    (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)))
    <bea>   DW_AT_GNU_call_site_value: 10 byte block: 74 0 f3 1 51 21 f3 1 52 27        (DW_OP_breg4 (r4): 0; DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_or; DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor)
    <bfe>   DW_AT_GNU_call_site_value: 5 byte block: f3 1 51 32 24      (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_lit2; DW_OP_shl)
    <cb8>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 53    (DW_OP_GNU_entry_value: (DW_OP_reg3 (r3)))
    <cbf>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 51    (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)))
    <cc6>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 52    (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)))
    <d2b>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 51    (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)))
    <d32>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 52    (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)))
    <d39>   DW_AT_GNU_call_site_value: 11 byte block: f3 1 51 f3 1 52 22 f3 1 50 27     (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_plus; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor)
    <da6>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 50    (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)))
    <db2>   DW_AT_GNU_call_site_value: 7 byte block: f3 1 50 f3 1 52 27         (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor)
    <e1f>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 52    (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)))
    <f65>   DW_AT_entry_pc    : 0x48
    <f69>   DW_AT_GNU_entry_view: 1
    <1030>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 50   (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)))
    <1037>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 53   (DW_OP_GNU_entry_value: (DW_OP_reg3 (r3)))
    <1044>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 52   (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)))
    <10a4>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 50   (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)))
    <10ab>   DW_AT_GNU_call_site_value: 7 byte block: f3 1 52 f3 1 53 27        (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_GNU_entry_value: (DW_OP_reg3 (r3)); DW_OP_xor)
    <10b6>   DW_AT_GNU_call_site_value: 7 byte block: 91 0 6 f3 1 53 1a         (DW_OP_fbreg: 0; DW_OP_deref; DW_OP_GNU_entry_value: (DW_OP_reg3 (r3)); DW_OP_and)
    <10c1>   DW_AT_GNU_call_site_value: 3 byte block: f3 1 53   (DW_OP_GNU_entry_value: (DW_OP_reg3 (r3)))
    DW_AT_entry_pc     DW_FORM_addr
    DW_AT_GNU_entry_view DW_FORM_data1
    DW_AT_entry_pc     DW_FORM_addr
    DW_AT_GNU_entry_view DW_FORM_data1
             00000087 0000008a (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000080 0000008a (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000084 0000008a (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000088 0000008a (DW_OP_GNU_entry_value: (DW_OP_reg3 (r3)); DW_OP_stack_value)
             00000080 00000082 (DW_OP_breg4 (r4): 0; DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_or; DW_OP_breg2 (r2): 0; DW_OP_xor; DW_OP_stack_value)
             00000087 00000088 (DW_OP_breg4 (r4): 0; DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_or; DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor; DW_OP_stack_value)
             00000087 00000088 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_lit2; DW_OP_shl; DW_OP_stack_value)
             00000087 00000088 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000064 00000066 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000063 00000066 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000063 00000066 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000063 00000066 (DW_OP_GNU_entry_value: (DW_OP_reg3 (r3)); DW_OP_stack_value)
             00000059 0000005c (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_plus; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_xor; DW_OP_stack_value)
             00000059 0000005c (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000059 0000005c (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000047 0000004a (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000047 0000004a (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_xor; DW_OP_stack_value)
             00000042 0000004a (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             0000003c 0000003e (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             0000003c 0000003e (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             0000002d 00000034 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             0000003c 0000003c (DW_OP_breg5 (r5): 0; DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_plus; DW_OP_stack_value) (start == end)
             0000003c 0000003e (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_plus; DW_OP_stack_value)
             00000016 00000020 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000014 00000020 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000007 00000088 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000007 00000088 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000073 00000076 (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000074 00000076 (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000073 00000076 (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000073 00000076 (DW_OP_GNU_entry_value: (DW_OP_reg3 (r3)); DW_OP_stack_value)
             00000097 0000009a (DW_OP_GNU_entry_value: (DW_OP_reg0 (r0)); DW_OP_stack_value)
             00000098 0000009a (DW_OP_GNU_entry_value: (DW_OP_reg1 (r1)); DW_OP_stack_value)
             00000094 0000009a (DW_OP_GNU_entry_value: (DW_OP_reg2 (r2)); DW_OP_stack_value)
             00000097 0000009a (DW_OP_GNU_entry_value: (DW_OP_reg3 (r3)); DW_OP_stack_value)
  0x0000c6f0 45445228 4750494f 47290065 6e747279 EDR(GPIOG).entry
*/


volatile int entry_test, last_a, last_b, last_c;

int f0(int a, int b, int c)// a=80, b=-640, c=80
{
	//a ^= b;
	//b >>= c;
	last_a = a, last_b = b, last_c = c;
	entry_test += a * b + c;
	return a + b * entry_test - c;
}

int f3(int a, int b, int c)// a=2591, b=0xffff fd80 (-640), c=80
{
	f0(c, b, a);// f0(80, -640, 2591)
	c = b + a;
	return f0(a * b + c, b, c);
}

int f2(int a, int b, int c)// a=69, b=88, c=465
{
	b -= a ^ c;// b=-316(0xffff fec4)
	return f3(a ^ 0xa5a, b << (c & 0xf), c + (b - a));// f3(2591, 0xffff fd88(4 294 966 664), 80)
}

int f1(int a, int b, int c)// a=332, b=69, c=88
{
	a ^= b + c;// a=465
	return f2(b, c, a);// f2(69, 88, 465)
}

int gate1(int(*f)(int,int,int), int a, int b, int c)// f=f1, a=69, b=88, c=332
{
	return f(c, a, b);// f1(332, 69, 88)
}

int gate2(int(*f)(int,int,int), int a, int b, int c)// f=f1, a=88, b=332, c=69
{
	return gate1(f, c, a, b);// gate1(f1, 69, 88, 332)
}

int gate3(int(*f)(int,int,int), int a, int b, int c)// f=f1, a=83, b=18, c=87
{
	return gate2(f, c + 1, a << 2, b ^ (a | c));// gate2(f1, 88, 332, 69)
}

int gate4(int(*f1)(int,int,int), int(*f2)(int(*)(int,int,int),int,int,int), int a, int b, int c) // f1=f1, f2=gate3, a=0x69(105), b=0x3a(58), c=0x57(87)
{
	return f2(f1, a ^ b, b & c, b);// gate3(f1, 83, 18, 58);
}

#endif
