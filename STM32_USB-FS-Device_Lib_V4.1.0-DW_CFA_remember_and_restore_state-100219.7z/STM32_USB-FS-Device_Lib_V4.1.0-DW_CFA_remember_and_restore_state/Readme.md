This is the old ST usb full speed libraries and examples source code

There are interesting tests for the troll here, arising from some of the examples

This specific one was built with the, as of 2019, free Truestudio IDE - the toolchain is gcc
This sample elf (STM3210B-EVAL.elf) provides tests for call frame operations DW_CFA_remember_state/DW_CFA_restore_state. Of particular interest is the frame unwind information for function CBW_Decode
