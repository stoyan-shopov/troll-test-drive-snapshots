Test for entry values, and call sites
There are also location views here
The backtrace is different from gdb
