#!/bin/sh

CFLAGS="-ggdb3 -gdwarf-4 -fvar-tracking -fvar-tracking-assignments -O3" make
