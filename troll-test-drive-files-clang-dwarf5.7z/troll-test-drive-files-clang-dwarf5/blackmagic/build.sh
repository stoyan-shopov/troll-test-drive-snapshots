#!/bin/bash

#############################
CFLAGS="-O3 -gdwarf-5 -ggdb3 -finline-functions -I/c/Program\ Files\ \(x86\)/GNU\ Tools\ ARM\ Embedded/9\ 2019-q4-major/arm-none-eabi/include/" make
