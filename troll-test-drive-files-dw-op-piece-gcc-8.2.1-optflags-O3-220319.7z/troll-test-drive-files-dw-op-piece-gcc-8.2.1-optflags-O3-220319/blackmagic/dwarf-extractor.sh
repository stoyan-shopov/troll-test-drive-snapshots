grep -o '\bDW_\w*\b' dwarf-4-clang-7-O3.txt | sort | uniq
grep -o '\bDW_\w*\b' dwarf-qt53drender.txt > dwarven-demolition-squad.txt
