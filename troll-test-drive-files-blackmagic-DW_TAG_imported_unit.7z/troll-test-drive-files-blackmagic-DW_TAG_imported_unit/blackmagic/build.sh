#!/bin/sh

CFLAGS="-gdwarf-4 -ggdb3 -g3 -O3 -std=gnu99 -finline-functions -fvar-tracking -fvar-tracking-assignments -flto -ffat-lto-objects" make

